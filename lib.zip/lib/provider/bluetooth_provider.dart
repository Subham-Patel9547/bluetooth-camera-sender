import 'package:flutter/material.dart';

import '../core/services/native_bluetooth_service.dart';

class BluetoothProvider extends ChangeNotifier {
  final NativeBluetoothService _service =
      NativeBluetoothService();

  List<Map<String, dynamic>> devices = [];

  bool connected = false;
  bool loading = false;

  String status = "Not Connected";

  /// Load paired devices
  Future<void> loadDevices() async {
    loading = true;
    notifyListeners();

    devices = await _service.getPairedDevices();

    loading = false;
    notifyListeners();
  }

  /// Connect to receiver
  Future<void> connect(String address) async {
    loading = true;
    status = "Connecting...";
    notifyListeners();

    final bool ok =
        await _service.connect(address);

    loading = false;

    if (ok) {
      connected = true;
      status = "Connected";
    } else {
      connected = false;
      status = "Connection Failed";
    }

    notifyListeners();
  }

  /// START
  Future<void> startRecording() async {
    if (!connected) return;

    bool ok =
        await _service.sendCommand("START");

    if (ok) {
      status = "START Sent";
    } else {
      status = "Failed to Send START";
    }

    notifyListeners();
  }

  /// STOP
  Future<void> stopRecording() async {
    if (!connected) return;

    bool ok =
        await _service.sendCommand("STOP");

    if (ok) {
      status = "STOP Sent";
    } else {
      status = "Failed to Send STOP";
    }

    notifyListeners();
  }

  /// Refresh paired devices
  Future<void> refresh() async {
    await loadDevices();
  }
}