import 'package:flutter/services.dart';

class NativeBluetoothService {
  static const MethodChannel _channel =
      MethodChannel("bluetooth_camera");

  /// Get paired devices
  Future<List<Map<String, dynamic>>> getPairedDevices() async {
    try {
      final List result =
          await _channel.invokeMethod("getPairedDevices");

      return result
          .map((e) => Map<String, dynamic>.from(e))
          .toList();
    } catch (e) {
      print("getPairedDevices Error: $e");
      return [];
    }
  }

  /// Connect to Receiver
  Future<bool> connect(String address) async {
    try {
      final bool connected =
          await _channel.invokeMethod(
        "connectDevice",
        {
          "address": address,
        },
      );

      return connected;
    } catch (e) {
      print("Connect Error: $e");
      return false;
    }
  }

  /// Send START / STOP
  Future<bool> sendCommand(String command) async {
    try {
      final bool sent =
          await _channel.invokeMethod(
        "sendCommand",
        {
          "command": command,
        },
      );

      return sent;
    } catch (e) {
      print("Send Error: $e");
      return false;
    }
  }
}