import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../provider/bluetooth_provider.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<BluetoothProvider>().loadDevices();
    });
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<BluetoothProvider>();

    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text("Bluetooth Camera Sender"),
        actions: [
          IconButton(
            onPressed: () {
              provider.refresh();
            },
            icon: const Icon(Icons.refresh),
          )
        ],
      ),
      body: Column(
        children: [

          /// STATUS
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(15),
            color: Colors.blue.shade50,
            child: Text(
              provider.status,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),

          /// DEVICE LIST
          Expanded(
            child: provider.loading
                ? const Center(
                    child: CircularProgressIndicator(),
                  )
                : provider.devices.isEmpty
                    ? const Center(
                        child: Text(
                          "No Paired Devices Found",
                          style: TextStyle(fontSize: 18),
                        ),
                      )
                    : ListView.builder(
                        itemCount: provider.devices.length,
                        itemBuilder: (context, index) {

                          final device =
                              provider.devices[index];

                          return Card(
                            margin: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 6,
                            ),
                            child: ListTile(
                              leading: const Icon(
                                Icons.bluetooth,
                                color: Colors.blue,
                              ),
                              title: Text(
                                device["name"] ?? "Unknown",
                              ),
                              subtitle: Text(
                                device["address"] ?? "",
                              ),
                              trailing: ElevatedButton(
                                onPressed: () async {
                                  await provider.connect(
                                    device["address"],
                                  );
                                },
                                child: const Text("Connect"),
                              ),
                            ),
                          );
                        },
                      ),
          ),

          const Divider(),

          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [

                Expanded(
                  child: ElevatedButton(
                    onPressed: provider.connected
                        ? () async {
                            await provider.startRecording();
                          }
                        : null,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                    ),
                    child: const Text("START"),
                  ),
                ),

                const SizedBox(width: 15),

                Expanded(
                  child: ElevatedButton(
                    onPressed: provider.connected
                        ? () async {
                            await provider.stopRecording();
                          }
                        : null,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red,
                    ),
                    child: const Text("STOP"),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 15),
        ],
      ),
    );
  }
}